<?php
/**
 * Template Name: Discography
 */

$post_type = 'album';
get_template_part('archive'); ?>