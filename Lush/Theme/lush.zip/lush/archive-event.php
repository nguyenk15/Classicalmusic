<?php
/**
 * Template Name: Event Posts
 */

$post_type = 'event';
get_template_part('archive'); ?>