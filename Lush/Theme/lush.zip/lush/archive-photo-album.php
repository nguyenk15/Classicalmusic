<?php
/**
 * Template Name: Photo Albums
 */
 
$post_type = 'photo-album';
$item_template = 'photo-album';

get_template_part('archive'); ?>