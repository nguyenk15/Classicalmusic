<?php
/**
 * Template Name: Blog Posts (Grid 3-Columns)
 */

$post_type = 'post';
$item_template = 'post_isotope';
$isocol = 'iso3';

get_template_part('archive'); ?>