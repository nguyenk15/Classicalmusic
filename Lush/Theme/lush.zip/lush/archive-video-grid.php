<?php
/**
 * Template Name: Video Posts (Grid)
 */
 
$post_type = 'video';
$item_template = 'video_grid';

get_template_part('archive'); ?>