<?php
$template = get_iron_option('post_archive_default_template');
include_once(locate_template($template.".php")); 
?>