<?php
/**
 * Template Name: Blog Posts (List)
 */

$post_type = 'post';
$item_template = 'post';

get_template_part('archive'); ?>