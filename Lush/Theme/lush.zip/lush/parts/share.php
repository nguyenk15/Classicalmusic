				<!-- links-block -->
				<aside class="links-block">
					<a href="#" onclick="window.history.back(); return false;" class="back-btn"><?php echo __("Back", IRON_TEXT_DOMAIN); ?></a>
					<div class="buttons">
						<?php echo get_iron_option('custom_social_actions'); ?>
					</div>
				</aside>
