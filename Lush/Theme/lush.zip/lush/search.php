<?php
$post_type = 'post';
$item_template = 'post_grid';
get_template_part('archive');
?>